#!/usr/bin/env python3
"""MCPTrust end-to-end demo -- the walkthrough for the 5-minute video.

Runs the full auditor over the whole corpus: one CLEAN server (TRUSTED) and five
INERT poisoned servers (each a different threat class), printing a rich report
for each. This is the "watch the scored trust report emerge" money shot.

    python demo/demo.py

No API key required -- the deterministic engine drives everything. Add
GOOGLE_API_KEY and pass --agents to also route through the ADK orchestrator.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mcptrust.agents.orchestrator import vibe_diff
from mcptrust.analyzers import audit_path
from mcptrust.report import render_terminal, summary_text

CORPUS = Path(__file__).resolve().parents[1] / "corpus"

SCENARIOS = [
    ("A trustworthy weather server", "clean/weather-server"),
    ("Prompt injection hidden in a tool description", "poisoned/injection-in-description"),
    ("A server with hardcoded (fake) credentials", "poisoned/hardcoded-secret"),
    ("An invisible Unicode payload (looks clean to a human)", "poisoned/invisible-unicode"),
    ("A 'calculator' that over-scopes and exfiltrates", "poisoned/overscoped-exfil"),
    ("Typosquatted / unpinned dependencies", "poisoned/typosquat-deps"),
]


def main() -> int:
    use_agents = "--agents" in sys.argv
    try:
        from rich.console import Console
        from rich.rule import Rule

        console = Console()
        banner = console.print
    except ImportError:
        console = None
        banner = print

    for title, rel in SCENARIOS:
        if console:
            console.print(Rule(f"[bold]{title}[/]  ({rel})"))
        else:
            print(f"\n=== {title} ({rel}) ===")

        if use_agents:
            from mcptrust.agents.orchestrator import audit_with_agents

            report = audit_with_agents(str(CORPUS / rel))
        else:
            report = audit_path(str(CORPUS / rel))
            report.summary = summary_text(report)

        render_terminal(report)

        diff = vibe_diff(report)
        if diff:
            if console:
                console.print(f"[red]{diff}[/]")
            else:
                print(diff)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
