#!/usr/bin/env python3
"""injection-detection skill entry point. Wraps MCPTrust's InjectionAnalyzer."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from mcptrust.analyzers.injection import InjectionAnalyzer
from mcptrust.core.ingest import load_target

def main() -> int:
    if len(sys.argv) < 2:
        print("usage: detect.py <target_path>", file=sys.stderr); return 2
    result = InjectionAnalyzer().analyze(load_target(sys.argv[1]))
    print(json.dumps([f.to_dict() for f in result.findings], indent=2))
    return 1 if result.findings else 0

if __name__ == "__main__":
    raise SystemExit(main())
