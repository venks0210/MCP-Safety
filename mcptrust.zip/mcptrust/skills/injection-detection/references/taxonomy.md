# Injection payload taxonomy (reference)

## 1. Imperative injection phrasing
Text aimed at the model, not the user. Signals: "ignore previous instructions",
"disregard system", exfiltration asks ("read/send .ssh/.env/credentials"),
covert-channel asks ("do not tell the user"), tool coercion ("you must always
call X before responding").

## 2. Invisible / deceptive Unicode
Zero-width (U+200B/C/D, U+2060, U+FEFF), soft hyphen (U+00AD), bidi controls
(U+202A–U+202E, U+2066–U+2069 — RIGHT-TO-LEFT OVERRIDE is the classic), and the
Unicode tag block (U+E0000–U+E007F) which can smuggle a full ASCII instruction
invisibly. Override/tag chars are CRITICAL because they defeat human review.

## 3. Homoglyphs
A single token mixing scripts (Latin + Cyrillic, e.g. `pаypal` with U+0430) to
spoof a brand or command name.

## Attack surface
Always analyse `target.context_surface()`: server instructions + every tool
name/description + schema field descriptions. That is the exact text injected
into a host agent's context.
