# MCPTrust Agent Skills

Four skills, one per threat class, each following the agentskills.io standard
(SKILL.md + scripts + references + evals). Progressive disclosure: the metadata
description is the routing algorithm; bodies and references load on demand.

- `secret-scanning/`      — hardcoded credentials
- `injection-detection/`  — prompt injection + hidden Unicode + homoglyphs
- `scope-auditing/`       — over-scoped permissions
- `dependency-hygiene/`   — typosquats + unpinned versions

Each skill's `scripts/` wrap the shared, tested analyzer in `mcptrust/analyzers/`
so the skill and the core never duplicate detection logic. Each `evals/cases.json`
holds Evaluation-Driven-Development cases written before the skill body.
