---
name: dependency-hygiene
description: >
  Detect dependency supply-chain risks — typosquats, slopsquatting (hallucinated
  package names), and unpinned versions — in an MCP server or skill before
  installing it. Use this skill whenever you audit a server's requirements /
  dependencies, or a user asks "are these packages safe?", "is this a typosquat?",
  or "are the versions pinned?" Do NOT use for secrets, injection, or scope
  (those have their own skills).
version: 1.0.0
license: MIT
allowed-tools: [Read, Bash]
---

# dependency-hygiene

## When to use
- Auditing `requirements.txt` / dependency manifests before install.
- User asks about "typosquat", "slopsquatting", "pinned versions", or "supply chain".

## Why this matters
LLMs hallucinate package names; attackers pre-register those exact fake names
with malware (slopsquatting, Day 4). Unpinned versions let a future compromised
release slip in. Typosquats (`reqests`, `python-dateutl`) mimic popular packages.

## Workflow
1. `python scripts/check.py <target_path>`
2. Any `typosquat_dependency` → HIGH (confirm you meant the real package).
3. `unpinned_dependency` → LOW (pin exact versions for reproducibility).

## Output format
JSON findings, `threat_class` in {`typosquat_dependency`, `unpinned_dependency`}.
