---
name: secret-scanning
description: >
  Detect hardcoded credentials (API keys, tokens, private keys, assigned secret
  literals) in an MCP server or Agent Skill folder before installing it. Use this
  skill whenever you are auditing, reviewing, or vetting a third-party MCP server,
  a community skill, or any untrusted code folder for leaked secrets, embedded
  keys, or credential hygiene — even if the user only says "is this server safe?"
  Do NOT use for scanning prompt-injection text (use injection-detection) or for
  auditing permissions (use scope-auditing).
version: 1.0.0
license: MIT
allowed-tools: [Read, Bash]
---

# secret-scanning

## When to use
- Vetting a third-party MCP server or community skill before installation.
- A user asks whether a server "leaks keys", "has hardcoded secrets", or "is safe to install".
- As one stage of a full MCPTrust audit.

## When NOT to use
- Detecting prompt injection in tool descriptions → use `injection-detection`.
- Auditing declared permissions/scopes → use `scope-auditing`.

## Why this matters
An MCP server that ships an embedded credential either leaks the author's key or
is a decoy that exfiltrates yours. Credentials must be loaded from environment
variables at runtime, never committed to source (Day 2 & Day 5). This is the same
rule the competition enforces on submissions ("no API keys in code").

## Workflow
1. Run the scanner over the target folder:
   ```bash
   python scripts/scan.py <target_path>
   ```
2. For each finding, confirm it is a real secret (not a placeholder or an
   `os.environ` lookup — the scanner already filters those).
3. Any CRITICAL finding (AWS/Google/OpenAI/GitHub key, private-key block) means
   BLOCK: do not install until removed and the exposed secret rotated.
4. See `references/patterns.md` for the full detection table and false-positive rules.

## Output format
A JSON list of findings: `{severity, threat_class: "hardcoded_secret", location, evidence (redacted), remediation}`.
Evidence is always redacted — the report never echoes a full secret.

## Anti-patterns to avoid
- Do NOT treat `api_key = os.environ["KEY"]` as a finding (that is the *correct* pattern).
- Do NOT echo a full matched secret anywhere in output.
