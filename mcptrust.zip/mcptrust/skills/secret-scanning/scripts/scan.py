#!/usr/bin/env python3
"""secret-scanning skill entry point. Thin wrapper over MCPTrust's SecretScanner
so the skill and the core share one tested implementation (Day 3: one job, no
duplicated logic)."""
import json
import sys
from pathlib import Path

# Make the mcptrust package importable whether run from repo root or skill dir.
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from mcptrust.analyzers.secrets import SecretScanner
from mcptrust.core.ingest import load_target


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: scan.py <target_path>", file=sys.stderr)
        return 2
    target = load_target(sys.argv[1])
    result = SecretScanner().analyze(target)
    print(json.dumps([f.to_dict() for f in result.findings], indent=2))
    return 1 if result.findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
