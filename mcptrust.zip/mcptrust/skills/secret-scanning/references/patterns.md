# Secret detection patterns (reference)

Loaded on demand (progressive disclosure). Full table of credential shapes the
scanner matches and the false-positive rules that suppress placeholders.

| Pattern | Example shape | Severity |
|---|---|---|
| AWS access key id | `AKIA` + 16 upper/digits | CRITICAL |
| Google API key | `AIza` + 35 chars | CRITICAL |
| OpenAI-style key | `sk-` + 20+ chars | CRITICAL |
| GitHub token | `ghp_`/`gho_`… + 36+ | CRITICAL |
| Slack token | `xoxb-`/`xoxp-`… | HIGH |
| Private key block | `-----BEGIN … PRIVATE KEY-----` | CRITICAL |
| Assigned secret literal | `password = "…"` (8+ chars) | HIGH |

## False-positive suppression
A line is NOT flagged if it contains any of: `your…`, `example`, `placeholder`,
`changeme`, `xxxx`, `<…>`, `{{…}}`, `env`, `os.environ`, `getenv`. These indicate
a placeholder or a correct env-var lookup, not a committed secret.

## Redaction
Evidence is always redacted to `first6…last2 (N chars)` so the audit report can
never itself become a secret-leak vector.
