#!/usr/bin/env python3
"""scope-auditing entry point. Wraps MCPTrust's ScopeAnalyzer."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from mcptrust.analyzers.scope import ScopeAnalyzer
from mcptrust.core.ingest import load_target

def main() -> int:
    if len(sys.argv) < 2:
        print("usage: audit.py <target_path>", file=sys.stderr); return 2
    result = ScopeAnalyzer().analyze(load_target(sys.argv[1]))
    print(json.dumps([f.to_dict() for f in result.findings], indent=2))
    return 1 if result.findings else 0

if __name__ == "__main__":
    raise SystemExit(main())
