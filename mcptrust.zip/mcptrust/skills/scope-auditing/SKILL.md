---
name: scope-auditing
description: >
  Audit an MCP server's declared permissions/scopes for least-privilege
  violations before installing it. Use this skill whenever you review or vet an
  MCP server for over-broad access, wildcard scopes, shell/filesystem/secrets
  permissions, or "does this server ask for more than it needs?" — even if the
  user just asks "is this server over-privileged?" Do NOT use for secrets
  (secret-scanning), injection (injection-detection), or dependencies
  (dependency-hygiene).
version: 1.0.0
license: MIT
allowed-tools: [Read, Bash]
---

# scope-auditing

## When to use
- Checking whether a server requests least privilege before install.
- User asks about "permissions", "over-scoped", "wildcard access", or "Confused Deputy" risk.

## When NOT to use
- Secrets → `secret-scanning`; injection → `injection-detection`; deps → `dependency-hygiene`.

## Why this matters
An MCP server should request the least privilege its job needs (Day 4, Pillar 5:
Zero Ambient Authority / Confused Deputy). A "calculator" that declares `*`,
`shell`, `env:read`, or `filesystem:*` is either badly designed or a trojan —
over-scope is what turns a prompt-injected server into real damage.

## Workflow
1. `python scripts/audit.py <target_path>`
2. Any `*`, `shell`, `exec`, or `secrets:read` scope → CRITICAL unless the stated
   purpose clearly justifies it (the analyzer downgrades justified scopes but
   still surfaces them for confirmation).
3. Servers with no manifest earn a LOW "unverifiable scope" note — prefer servers
   that declare scopes explicitly.

## Output format
JSON findings, `threat_class` in {`overscoped_permission`, `unverifiable_scope`}.
