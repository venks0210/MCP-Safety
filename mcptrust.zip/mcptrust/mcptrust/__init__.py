"""MCPTrust: audit MCP servers & agent skills before you install them."""
__version__ = "0.1.0"
