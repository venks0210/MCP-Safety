"""Report renderers: turn a TrustReport into something a human (or a video
audience) can read at a glance.

We ship three renderers:
  - terminal (rich) : the money shot for the demo video
  - markdown        : for GitHub Action PR comments / docs
  - the summary()   : a deterministic plain-English 'Vibe Diff'-style fallback
                      used when no LLM key is available, so the product is fully
                      functional offline (Day 4 'Vibe Diff': translate machine
                      findings into plain language before a human decides).
"""

from __future__ import annotations

from ..core.models import Severity, TrustReport

_VERDICT_BLURB = {
    "TRUSTED": "No high-severity issues found. Safe to install with normal review.",
    "REVIEW": "Some concerns found. A human should review before installing.",
    "BLOCK": "Serious issues found. Do NOT install without fixing these first.",
}


def summary_text(report: TrustReport) -> str:
    """Deterministic plain-English summary (no LLM required).

    This is the offline 'Vibe Diff': it states the verdict, why, and the single
    most important thing to do next -- in words a non-security-specialist can act
    on. The ADK report agent may replace this with an LLM-written version when a
    key is present, but the product never depends on that."""
    lines = [f"Verdict: {report.verdict} (trust score {report.score}/100)."]
    lines.append(_VERDICT_BLURB.get(report.verdict, ""))

    crit = [f for f in report.findings if f.severity is Severity.CRITICAL]
    high = [f for f in report.findings if f.severity is Severity.HIGH]
    if crit:
        lines.append(
            f"{len(crit)} critical issue(s) forced a BLOCK. Most urgent: "
            f"{crit[0].title} ({crit[0].location})."
        )
    elif high:
        lines.append(f"Top concern: {high[0].title} ({high[0].location}).")
    elif report.verdict == "TRUSTED":
        lines.append("This server requests least privilege and ships no risky patterns.")
    return " ".join(x for x in lines if x)


_COLOR = {
    "TRUSTED": "bold green",
    "REVIEW": "bold yellow",
    "BLOCK": "bold red",
}
_SEV_COLOR = {
    "CRITICAL": "red",
    "HIGH": "dark_orange",
    "MEDIUM": "yellow",
    "LOW": "cyan",
    "INFO": "dim",
}


def render_terminal(report: TrustReport) -> None:
    """Pretty terminal output using rich. Falls back to plain text if rich is
    unavailable so the CLI never hard-depends on it."""
    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table
    except ImportError:  # pragma: no cover
        print(render_plain(report))
        return

    console = Console()
    color = _COLOR.get(report.verdict, "white")
    header = f"[{color}]{report.verdict}[/]  score [bold]{report.score}[/]/100   target: {report.target}"
    console.print(Panel(header, title="MCPTrust audit", border_style=color))
    console.print(report.summary or summary_text(report))

    if not report.findings:
        console.print("[green]No findings.[/]")
        return

    table = Table(show_lines=False, expand=True)
    table.add_column("Severity", no_wrap=True)
    table.add_column("Threat")
    table.add_column("Finding")
    table.add_column("Location", no_wrap=True)
    for f in report.findings:
        if f.severity is Severity.INFO:
            continue
        sev = f.severity.label
        table.add_row(
            f"[{_SEV_COLOR.get(sev,'white')}]{sev}[/]",
            f.threat_class,
            f.title,
            f.location,
        )
    console.print(table)


def render_plain(report: TrustReport) -> str:
    """Dependency-free plain-text renderer."""
    out = [
        f"MCPTrust audit :: {report.target}",
        f"VERDICT: {report.verdict}   SCORE: {report.score}/100",
        report.summary or summary_text(report),
        "",
    ]
    for f in report.findings:
        if f.severity is Severity.INFO:
            continue
        out.append(f"[{f.severity.label}] {f.title}  ({f.location})")
    if len(out) == 4:
        out.append("No findings.")
    return "\n".join(out)


def render_markdown(report: TrustReport) -> str:
    """Markdown for GitHub Action PR comments and docs."""
    badge = {"TRUSTED": "✅", "REVIEW": "⚠️", "BLOCK": "⛔"}.get(report.verdict, "")
    out = [
        f"## {badge} MCPTrust audit: `{report.target}`",
        "",
        f"**Verdict:** {report.verdict} — **Trust score:** {report.score}/100",
        "",
        f"> {report.summary or summary_text(report)}",
        "",
        "| Severity | Threat | Finding | Location |",
        "|---|---|---|---|",
    ]
    any_row = False
    for f in report.findings:
        if f.severity is Severity.INFO:
            continue
        any_row = True
        out.append(f"| {f.severity.label} | `{f.threat_class}` | {f.title} | `{f.location}` |")
    if not any_row:
        out.append("| — | — | No findings | — |")
    return "\n".join(out)
