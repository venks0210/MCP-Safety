"""Dangerous-call analyzer: unsafe execution & exfiltration patterns in code.

THREAT MODEL: an MCP server runs on *your* machine with *your* file access. A
tool that shells out on unsanitised input, `eval`s a payload, or POSTs local
files to an external host is how a "helpful" server becomes remote code
execution or data exfiltration (Day 4, Pillars 1 & 4).

DESIGN: we use Python's own `ast` module for the Python case -- parsing, never
executing. AST parsing is safe: it builds a syntax tree without running a line.
For non-Python files we fall back to conservative regex. Matching structure via
AST massively cuts false positives versus grepping for the string "eval".
"""

from __future__ import annotations

import ast
import re

from ..core.ingest import Target
from ..core.models import AnalyzerResult, Finding, Severity

NAME = "dangerous_calls"

# (dotted call name) -> (threat_class, severity, human explanation)
_DANGEROUS_CALLS: dict[str, tuple[str, Severity, str]] = {
    "os.system": ("shell_exec", Severity.HIGH, "executes a shell command"),
    "os.popen": ("shell_exec", Severity.HIGH, "opens a shell pipe"),
    "subprocess.call": ("shell_exec", Severity.MEDIUM, "runs a subprocess"),
    "subprocess.run": ("shell_exec", Severity.MEDIUM, "runs a subprocess"),
    "subprocess.Popen": ("shell_exec", Severity.MEDIUM, "spawns a subprocess"),
    "eval": ("dynamic_eval", Severity.HIGH, "evaluates a string as code"),
    "exec": ("dynamic_eval", Severity.HIGH, "executes a string as code"),
    "__import__": ("dynamic_import", Severity.MEDIUM, "imports a module by name at runtime"),
    "pickle.loads": ("unsafe_deserialize", Severity.HIGH, "deserialises arbitrary objects (RCE)"),
    "pickle.load": ("unsafe_deserialize", Severity.HIGH, "deserialises arbitrary objects (RCE)"),
    "marshal.loads": ("unsafe_deserialize", Severity.HIGH, "deserialises arbitrary objects"),
    "yaml.load": ("unsafe_deserialize", Severity.MEDIUM, "unsafe YAML load (use safe_load)"),
}

# Network sinks that, combined with reading local files, indicate exfiltration.
_NETWORK_CALLS = {"requests.post", "requests.put", "requests.get", "urllib.request.urlopen", "httpx.post", "httpx.get", "socket.socket"}
_FILE_READS = {"open", "pathlib.Path.read_text", "os.read"}


def _dotted(node: ast.AST) -> str:
    """Best-effort dotted name for a call target (e.g. os.system)."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parts = []
        cur: ast.AST | None = node
        while isinstance(cur, ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        if isinstance(cur, ast.Name):
            parts.append(cur.id)
        return ".".join(reversed(parts))
    return ""


class DangerousCallAnalyzer:
    name = NAME

    def analyze(self, target: Target) -> AnalyzerResult:
        result = AnalyzerResult(analyzer=self.name)
        for relpath, text in target.iter_text():
            if relpath.endswith(".py"):
                self._analyze_python(relpath, text, result)
            elif relpath.endswith((".js", ".ts")):
                self._analyze_js(relpath, text, result)
        return result

    def _analyze_python(self, relpath: str, text: str, result: AnalyzerResult) -> None:
        try:
            tree = ast.parse(text)
        except SyntaxError:
            return  # not valid Python; skip rather than guess

        saw_network = False
        saw_file_read = False
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = _dotted(node.func)
            if name in _DANGEROUS_CALLS:
                threat, sev, what = _DANGEROUS_CALLS[name]
                result.add(
                    Finding(
                        analyzer=self.name,
                        threat_class=threat,
                        severity=sev,
                        title=f"Dangerous call: {name}() ({what})",
                        detail=(
                            f"`{name}` {what}. In an MCP server that receives tool arguments "
                            "from a model, this is a direct path to code execution or data "
                            "exfiltration on the host running the server."
                        ),
                        location=f"{relpath}:{getattr(node, 'lineno', '?')}",
                        evidence=f"{name}(...)",
                        remediation="Avoid dynamic execution on model-supplied input; if a "
                        "subprocess is required, use an argv list with no shell=True and "
                        "validate every argument.",
                    )
                )
            if name in _NETWORK_CALLS:
                saw_network = True
            if name in _FILE_READS:
                saw_file_read = True

        # Correlation finding: reads local files AND talks to the network -> the
        # classic exfiltration shape. Flagged separately and only once.
        if saw_network and saw_file_read:
            result.add(
                Finding(
                    analyzer=self.name,
                    threat_class="exfiltration_shape",
                    severity=Severity.HIGH,
                    title="File-read + network-send in same module (exfiltration shape)",
                    detail="This module both reads local files and sends data over the "
                    "network. That combination is the signature of a data-exfiltration "
                    "tool. Verify what is read and where it is sent.",
                    location=relpath,
                    evidence="reads local files + outbound network call",
                    remediation="Confirm no sensitive path is read and forwarded; scope "
                    "outbound hosts to an explicit allowlist.",
                )
            )

    def _analyze_js(self, relpath: str, text: str, result: AnalyzerResult) -> None:
        for label, pattern, sev in (
            ("eval", re.compile(r"\beval\s*\("), Severity.HIGH),
            ("child_process exec", re.compile(r"child_process|\bexecSync?\s*\("), Severity.HIGH),
            ("Function constructor", re.compile(r"new\s+Function\s*\("), Severity.MEDIUM),
        ):
            m = pattern.search(text)
            if m:
                result.add(
                    Finding(
                        analyzer=self.name,
                        threat_class="dynamic_eval",
                        severity=sev,
                        title=f"Dangerous JS construct: {label}",
                        detail="Dynamic execution in a server that receives model-supplied "
                        "input can lead to remote code execution on the host.",
                        location=relpath,
                        evidence=m.group(0),
                        remediation="Remove dynamic execution; validate and dispatch on a fixed set of actions.",
                    )
                )
