"""Secret scanner: hardcoded credentials in a target MCP server.

WHY THIS MATTERS (Day 2 & Day 5): "never hardcode credentials -- rely on env
vars." A community MCP server that ships an embedded API key is either leaking
the author's key or, worse, a decoy that phones home. Either way it fails the
competition's own "no API keys in code" rule -- so MCPTrust enforces on other
people's servers exactly the rule we hold ourselves to. (Our CI runs this same
analyzer on our own repo: see .github/workflows/audit.yml. Dogfooding.)

DESIGN: pure regex over text. Deterministic, no network, no keys. We redact the
matched secret before it ever appears in a Finding so the report itself can't
become a secret-leak vector.
"""

from __future__ import annotations

import re

from ..core.ingest import Target
from ..core.models import AnalyzerResult, Finding, Severity

NAME = "secrets"

# Each pattern is (label, compiled regex, severity). Patterns target the shapes
# of real credentials. Kept intentionally conservative to limit false positives;
# generic "high entropy string" detection is deliberately omitted because it is
# noisy and better suited to a dedicated tool.
_PATTERNS: list[tuple[str, re.Pattern[str], Severity]] = [
    ("AWS access key id", re.compile(r"\bAKIA[0-9A-Z]{16}\b"), Severity.CRITICAL),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"), Severity.CRITICAL),
    ("OpenAI-style key", re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"), Severity.CRITICAL),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b"), Severity.CRITICAL),
    ("Slack token", re.compile(r"\bxox[abpr]-[A-Za-z0-9-]{10,}\b"), Severity.HIGH),
    ("Private key block", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"), Severity.CRITICAL),
    (
        "Assigned secret literal",
        # e.g.  api_key = "abcdef123456..."   password: 'hunter2hunter2'
        re.compile(
            r"(?i)\b(?:api[_-]?key|secret|passwd|password|token|auth[_-]?token)\b"
            r"\s*[:=]\s*['\"][^'\"]{8,}['\"]"
        ),
        Severity.HIGH,
    ),
]

# Values that look assigned but are obviously placeholders -> not a finding.
_PLACEHOLDER = re.compile(
    r"(?i)(your[_-]?|example|placeholder|changeme|xxxx|<[^>]+>|\{\{?[^}]+\}?\}|\benv\b|os\.environ|getenv)"
)


def _redact(match: str) -> str:
    """Show only enough to locate the secret; never echo it in full."""
    match = match.strip()
    if len(match) <= 12:
        return match[:2] + "***"
    return f"{match[:6]}...{match[-2:]} ({len(match)} chars)"


class SecretScanner:
    name = NAME

    def analyze(self, target: Target) -> AnalyzerResult:
        result = AnalyzerResult(analyzer=self.name)
        for relpath, text in target.iter_text():
            for line_no, line in enumerate(text.splitlines(), start=1):
                for label, pattern, severity in _PATTERNS:
                    m = pattern.search(line)
                    if not m:
                        continue
                    # Skip obvious placeholders / env lookups.
                    if _PLACEHOLDER.search(line):
                        continue
                    result.add(
                        Finding(
                            analyzer=self.name,
                            threat_class="hardcoded_secret",
                            severity=severity,
                            title=f"Possible hardcoded credential ({label})",
                            detail=(
                                "A literal that matches a credential pattern is committed "
                                "in source. Installing this server may leak the author's "
                                "secret into your environment, or the value may be a decoy "
                                "used to exfiltrate data. Credentials must come from env "
                                "vars at runtime, never source."
                            ),
                            location=f"{relpath}:{line_no}",
                            evidence=_redact(m.group(0)),
                            remediation="Load this value from an environment variable "
                            "(os.environ / .env) and rotate the exposed secret.",
                        )
                    )
        return result
