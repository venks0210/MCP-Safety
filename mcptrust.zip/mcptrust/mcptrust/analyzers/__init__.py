"""Analyzer registry + the deterministic audit engine.

`run_all` is MCPTrust's guaranteed-to-work core: it runs every analyzer over a
Target and returns a scored TrustReport using nothing but local Python. No API
key, no network, no model. The ADK agent layer (mcptrust/agents) orchestrates
these same analyzers and *adds* an LLM-written summary on top -- but if there is
no API key, the whole product still works via this path. That is the Day 1
"agentic engineering" discipline: the deterministic harness is the source of
truth; the model decorates it.
"""

from __future__ import annotations

from ..core.ingest import Target, load_target
from ..core.models import Finding, TrustReport
from ..core.scoring import build_report
from .base import Analyzer, safe_run
from .dangerous_calls import DangerousCallAnalyzer
from .dependencies import DependencyAnalyzer
from .injection import InjectionAnalyzer
from .scope import ScopeAnalyzer
from .secrets import SecretScanner

# Registry: threat class -> analyzer. Order is worst-first for readability only;
# scoring is order-independent.
ALL_ANALYZERS: list[Analyzer] = [
    InjectionAnalyzer(),
    SecretScanner(),
    DangerousCallAnalyzer(),
    ScopeAnalyzer(),
    DependencyAnalyzer(),
]


def run_all(target: Target, summary: str = "") -> TrustReport:
    """Run every analyzer and return a scored report (fully deterministic)."""
    findings: list[Finding] = []
    ran: list[str] = []
    for analyzer in ALL_ANALYZERS:
        res = safe_run(analyzer, target)
        ran.append(analyzer.name)
        if res.ok:
            findings.extend(res.findings)
        else:
            # Surface analyzer failure to the user rather than hiding it.
            from ..core.models import Finding as _F, Severity as _S

            findings.append(
                _F(
                    analyzer=analyzer.name,
                    threat_class="analyzer_error",
                    severity=_S.INFO,
                    title=f"Analyzer '{analyzer.name}' could not complete",
                    detail=res.error,
                    location="(analyzer)",
                )
            )
    return build_report(target.name, findings, ran, summary=summary)


def audit_path(path: str, summary: str = "") -> TrustReport:
    """Convenience: load a target from disk and run the full deterministic audit."""
    return run_all(load_target(path), summary=summary)


__all__ = [
    "ALL_ANALYZERS",
    "run_all",
    "audit_path",
    "DangerousCallAnalyzer",
    "DependencyAnalyzer",
    "InjectionAnalyzer",
    "ScopeAnalyzer",
    "SecretScanner",
]
