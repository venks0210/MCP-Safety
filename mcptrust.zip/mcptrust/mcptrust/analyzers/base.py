"""The Analyzer contract.

Every detection engine is a small, single-purpose unit that takes a loaded
Target and returns an AnalyzerResult. This mirrors the Day 3 "one skill, one
job" rule: each analyzer maps 1:1 to a threat class and a SKILL.md, so the
agent layer, the CLI, and the skills library all reference the exact same
detection logic. No duplication, one source of truth per threat.
"""

from __future__ import annotations

from typing import Protocol

from ..core.ingest import Target
from ..core.models import AnalyzerResult


class Analyzer(Protocol):
    name: str

    def analyze(self, target: Target) -> AnalyzerResult:  # pragma: no cover
        ...


def safe_run(analyzer: "Analyzer", target: Target) -> AnalyzerResult:
    """Run an analyzer, converting any crash into a non-fatal errored result.

    A single buggy or adversarially-crafted file must never take the whole audit
    down (Day 4: "invisible failures"). If an analyzer throws, we record it as an
    errored AnalyzerResult and keep going, so the user still gets a report plus a
    clear note that one engine could not complete.
    """
    try:
        return analyzer.analyze(target)
    except Exception as exc:  # noqa: BLE001 - deliberately broad; see docstring
        return AnalyzerResult(analyzer=analyzer.name, ok=False, error=repr(exc))
