"""Dependency hygiene: slopsquatting, unpinned versions, typosquats.

THREAT MODEL (Day 4 -- "slopsquatting"): LLMs hallucinate package names;
attackers pre-register those exact fake names with malware, so an agent that
auto-installs deps pulls the malware in. Related classics: unpinned versions
(today's clean dep is tomorrow's compromised release) and typosquats of popular
packages (`reqests`, `python-dateutl`).

DESIGN: parse requirements.txt / package.json / pyproject text (never install).
Deterministic string analysis. The typosquat check uses edit-distance against a
small, embedded list of very common packages -- enough to demonstrate the
mechanism without shipping a 400k-name index.
"""

from __future__ import annotations

import re

from ..core.ingest import Target
from ..core.models import AnalyzerResult, Finding, Severity

NAME = "dependencies"

# A tiny, illustrative popular-package list. In production this would be a large
# curated index; kept small here so the repo is self-contained and offline.
_POPULAR = {
    "requests", "numpy", "pandas", "flask", "django", "fastapi", "pydantic",
    "aiohttp", "httpx", "boto3", "pyyaml", "python-dateutil", "cryptography",
    "sqlalchemy", "openai", "anthropic", "google-adk", "mcp", "click", "rich",
}


def _levenshtein(a: str, b: str) -> int:
    """Classic edit distance -- for typosquat proximity."""
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _parse_requirements(text: str) -> list[tuple[str, bool]]:
    """Return (package_name, is_pinned) for each requirement line."""
    out: list[tuple[str, bool]] = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        name = re.split(r"[<>=!~\[ ]", line, 1)[0].strip().lower()
        if not name:
            continue
        pinned = "==" in line
        out.append((name, pinned))
    return out


class DependencyAnalyzer:
    name = NAME

    def analyze(self, target: Target) -> AnalyzerResult:
        result = AnalyzerResult(analyzer=self.name)
        for relpath, text in target.iter_text():
            base = relpath.rsplit("/", 1)[-1].lower()
            if base in {"requirements.txt", "requirements-dev.txt"}:
                self._check_reqs(relpath, text, result)
        return result

    def _check_reqs(self, relpath: str, text: str, result: AnalyzerResult) -> None:
        for name, pinned in _parse_requirements(text):
            if not pinned:
                result.add(
                    Finding(
                        analyzer=self.name,
                        threat_class="unpinned_dependency",
                        severity=Severity.LOW,
                        title=f"Unpinned dependency: {name}",
                        detail="An unpinned dependency can silently pull a future, "
                        "possibly-compromised release. Pin exact versions for supply-chain "
                        "reproducibility (Day 4).",
                        location=relpath,
                        evidence=name,
                        remediation=f"Pin an exact version, e.g. {name}==<known-good>.",
                    )
                )
            # Typosquat proximity check against popular packages.
            if name not in _POPULAR:
                for pop in _POPULAR:
                    dist = _levenshtein(name, pop)
                    if 0 < dist <= 1 and abs(len(name) - len(pop)) <= 1:
                        result.add(
                            Finding(
                                analyzer=self.name,
                                threat_class="typosquat_dependency",
                                severity=Severity.HIGH,
                                title=f"Possible typosquat: '{name}' ~ '{pop}'",
                                detail=f"'{name}' is one edit away from the popular package "
                                f"'{pop}'. This is the shape of a typosquat / slopsquat "
                                "supply-chain attack.",
                                location=relpath,
                                evidence=f"{name} vs {pop} (edit distance {dist})",
                                remediation=f"Confirm you meant '{pop}', not '{name}'.",
                            )
                        )
                        break
