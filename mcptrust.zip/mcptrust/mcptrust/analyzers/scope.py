"""Scope analyzer: over-broad permissions & purpose/capability mismatch.

THREAT MODEL (Day 4, Pillar 5 -- "Confused Deputy" + Zero Ambient Authority):
an MCP server should request the *least* privilege its job needs. A "weather"
server that declares filesystem write, shell access, or "*" scope is either
badly designed or a trojan. Over-scoped permissions are what let a prompt-
injected server actually do damage.

DESIGN: reads the committed manifest's declared permissions/scopes and compares
them against the server's stated purpose. Deterministic, manifest-driven.
"""

from __future__ import annotations

import re

from ..core.ingest import Target
from ..core.models import AnalyzerResult, Finding, Severity

NAME = "scope"

# Declared scopes we consider high-power. Maps scope token -> severity if present
# without clear justification.
_HIGH_POWER_SCOPES = {
    "filesystem:write": Severity.HIGH,
    "filesystem:*": Severity.HIGH,
    "shell": Severity.CRITICAL,
    "exec": Severity.CRITICAL,
    "network:*": Severity.MEDIUM,
    "env:read": Severity.HIGH,      # reading env = reading every secret on the host
    "secrets:read": Severity.CRITICAL,
    "*": Severity.CRITICAL,
    "admin": Severity.CRITICAL,
}

# Words in the server's description that would *justify* a powerful scope.
_JUSTIFIES_WRITE = re.compile(r"(?i)\b(write|save|create|edit|modify|delete|deploy|install)\b")
_JUSTIFIES_SHELL = re.compile(r"(?i)\b(shell|terminal|command|execute|run\s+code|build)\b")


class ScopeAnalyzer:
    name = NAME

    def analyze(self, target: Target) -> AnalyzerResult:
        result = AnalyzerResult(analyzer=self.name)
        manifest = target.manifest
        if not manifest:
            # No manifest to audit scope from -- report as an info-level gap so
            # the user knows scope could not be verified (absence of evidence).
            result.add(
                Finding(
                    analyzer=self.name,
                    threat_class="unverifiable_scope",
                    severity=Severity.LOW,
                    title="No manifest: declared permissions could not be verified",
                    detail="This server ships no machine-readable manifest, so its "
                    "requested permissions can't be checked before install. Prefer "
                    "servers that declare least-privilege scopes explicitly.",
                    location="(no manifest)",
                    remediation="Ask the author to publish an mcp.json declaring scopes.",
                )
            )
            return result

        purpose = " ".join(
            str(manifest.get(k, "")) for k in ("description", "summary", "name")
        )
        declared = manifest.get("permissions") or manifest.get("scopes") or []
        if isinstance(declared, str):
            declared = [declared]

        for scope in declared:
            scope_l = str(scope).strip().lower()
            severity = _HIGH_POWER_SCOPES.get(scope_l)
            if severity is None:
                continue

            # Downgrade if the stated purpose plausibly justifies the scope.
            justified = False
            if scope_l.startswith("filesystem") and _JUSTIFIES_WRITE.search(purpose):
                justified = True
            if scope_l in {"shell", "exec"} and _JUSTIFIES_SHELL.search(purpose):
                justified = True

            eff_sev = Severity.MEDIUM if justified else severity
            note = " (purpose plausibly justifies this, but confirm)" if justified else ""
            result.add(
                Finding(
                    analyzer=self.name,
                    threat_class="overscoped_permission",
                    severity=eff_sev,
                    title=f"High-power permission requested: '{scope}'{note}",
                    detail=(
                        f"The manifest requests '{scope}'. Grant an MCP server only the "
                        "least privilege its job needs; broad scopes turn a prompt-injected "
                        "server into a Confused Deputy with real reach on your machine."
                    ),
                    location=f"{target.manifest_path or 'manifest'}:permissions",
                    evidence=str(scope),
                    remediation="Down-scope to the specific paths/hosts the tool needs; "
                    "deny by default.",
                )
            )
        return result
