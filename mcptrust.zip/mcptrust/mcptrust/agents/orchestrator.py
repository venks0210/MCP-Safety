"""The MCPTrust multi-agent system (ADK) -- the 'Agent / Multi-agent' concept.

WHY MULTIPLE AGENTS (defensible per Day 2's bounded/unbounded test and Day 3's
'different trust posture' criterion -- not multi-agent for show):

  - Static-analysis, scope, and dependency work are BOUNDED, deterministic
    lookups -> exposed to a specialist agent as read-only tools.
  - The Red-Team agent operates on UNBOUNDED, adversarial input (the target's
    agent-visible text). It has a different job and a different trust posture:
    it reasons about "would this poison a host's context?", which is exactly the
    kind of open-ended judgement Day 2 says belongs to an agent, not a tool.
  - The Report agent SYNTHESISES across specialists and writes the plain-English
    Vibe Diff. It is the only agent that produces user-facing prose.

Each specialist is a real ADK LlmAgent wired to the deterministic analyzers via
FunctionTools, and every one carries the before_tool_guardrail security callback
(Policy Server + Zero Ambient Authority). The orchestrator is a SequentialAgent
that fans the target through the specialists and ends at the report agent.

GRACEFUL DEGRADATION: constructing the agents needs no API key (it's just
declarations). *Running* the LLM path needs GOOGLE_API_KEY. So `audit_with_agents`
always computes the deterministic report as the source of truth, and only calls
the model to upgrade the summary when a key is present. No key -> identical
verdict, deterministic summary. The product never breaks for lack of a key.
"""

from __future__ import annotations

from ..analyzers import audit_path
from ..core.models import Severity, TrustReport
from ..report import summary_text
from .llm import ORCHESTRATOR_MODEL, SUMMARY_MODEL, has_api_key
from .security import before_tool_guardrail
from .tools import (
    run_full_audit,
    scan_dangerous_calls,
    scan_dependencies,
    scan_injection,
    scan_scope,
    scan_secrets,
)

# ADK is an optional dependency (extras: [agents]). Import lazily so the
# deterministic product and its tests never hard-require it.
try:
    from google.adk.agents import LlmAgent, SequentialAgent

    _ADK = True
except ImportError:  # pragma: no cover
    _ADK = False


# --------------------------------------------------------------------------
# Agent definitions (only built if ADK is installed).
# --------------------------------------------------------------------------
def _build_agents():
    static_analysis_agent = LlmAgent(
        name="static_analysis_agent",
        model=SUMMARY_MODEL,
        description="Finds hardcoded secrets and dangerous code in a target server.",
        instruction=(
            "You audit an MCP server for hardcoded credentials and dangerous code. "
            "Call scan_secrets and scan_dangerous_calls on the given path and report "
            "every finding verbatim. Never execute the target; only read it."
        ),
        tools=[scan_secrets, scan_dangerous_calls],
        before_tool_callback=before_tool_guardrail,  # Policy Server gate
        output_key="static_findings",
    )

    scope_agent = LlmAgent(
        name="scope_agent",
        model=SUMMARY_MODEL,
        description="Audits declared permissions and dependency hygiene.",
        instruction=(
            "You check whether a server requests least privilege and pins safe "
            "dependencies. Call scan_scope and scan_dependencies on the path and "
            "report findings. Flag any wildcard or high-power scope."
        ),
        tools=[scan_scope, scan_dependencies],
        before_tool_callback=before_tool_guardrail,
        output_key="scope_findings",
    )

    redteam_agent = LlmAgent(
        name="redteam_agent",
        model=ORCHESTRATOR_MODEL,
        description="Adversarially inspects agent-visible text for context poisoning.",
        instruction=(
            "You are a red-team analyst. The text a server injects into a host "
            "agent's context (tool descriptions, server instructions) is your "
            "attack surface. Call scan_injection on the path and judge whether a "
            "host agent's context would be poisoned: prompt injection, hidden "
            "Unicode, or homoglyph spoofing. Explain the worst finding plainly."
        ),
        tools=[scan_injection],
        before_tool_callback=before_tool_guardrail,
        output_key="redteam_findings",
    )

    report_agent = LlmAgent(
        name="report_agent",
        model=SUMMARY_MODEL,
        description="Synthesises all findings into a plain-English trust verdict.",
        instruction=(
            "You write the final trust report for a developer deciding whether to "
            "install a server. Call run_full_audit for the authoritative score and "
            "verdict, then write a 2-3 sentence plain-English summary a "
            "non-security-specialist can act on. Lead with the verdict and the single "
            "most important reason. Never soften a BLOCK."
        ),
        tools=[run_full_audit],
        before_tool_callback=before_tool_guardrail,
        output_key="trust_report",
    )

    orchestrator = SequentialAgent(
        name="mcptrust_orchestrator",
        description="Auditor-in-chief: runs specialists in sequence, ends with the report.",
        sub_agents=[static_analysis_agent, scope_agent, redteam_agent, report_agent],
    )
    return orchestrator


# Build once at import if ADK is available (declarations only; no key needed).
ORCHESTRATOR = _build_agents() if _ADK else None


# --------------------------------------------------------------------------
# Vibe Diff (Day 4): plain-English translation of the critical findings a human
# is about to accept-or-reject. Deterministic; used with or without an LLM.
# --------------------------------------------------------------------------
def vibe_diff(report: TrustReport) -> str:
    crit = [f for f in report.findings if f.severity is Severity.CRITICAL]
    if not crit:
        return ""
    lines = ["VIBE DIFF -- what you would be approving if you install this:"]
    for f in crit:
        lines.append(f"  - {f.title}  [{f.location}]  =>  {f.remediation or 'do not install'}")
    return "\n".join(lines)


# --------------------------------------------------------------------------
# Public entry point used by the CLI (`--use-agents`).
# --------------------------------------------------------------------------
def audit_with_agents(path: str) -> TrustReport:
    """Run the audit via the agent layer where possible, deterministic always.

    The deterministic report is the source of truth (verdict + score + findings).
    When a key is present we ask the report agent to write a better summary; when
    it is not, we use the deterministic Vibe-Diff summary. Either way the verdict
    is identical, because the model never gets to change the score.
    """
    report = audit_path(path)                 # deterministic source of truth
    report.summary = summary_text(report)     # deterministic Vibe-Diff summary

    if not (_ADK and has_api_key()):
        # No agent runtime available -> return the deterministic result as-is.
        return report

    # LLM path: upgrade the prose summary only. (Kept intentionally small; a full
    # runner invocation is wired in demo/run_agents.py to keep this import-light.)
    try:
        from .runner import summarize_with_report_agent

        better = summarize_with_report_agent(path, report)
        if better:
            report.summary = better
    except Exception:  # noqa: BLE001 - summary is best-effort; verdict is not
        pass
    return report
