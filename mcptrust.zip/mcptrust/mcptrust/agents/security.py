"""Security guardrails for the agent layer, implemented as ADK tool callbacks.

This module is the concrete, in-code evidence for the 'Security features'
competition concept. It applies three ideas straight from the whitepapers to
MCPTrust's own agents:

  1. Policy Server / structural gating (Day 5): a deterministic check runs
     BEFORE any tool executes. Only a fixed allowlist of read-only audit tools
     may run; anything else is refused without ever asking the model.

  2. Zero Ambient Authority + file-tree allowlist (Day 4): audit tools may only
     read paths inside an explicitly allowed root. A prompt-injected orchestrator
     that tries to make the auditor read `~/.ssh/id_rsa` or escape via `../../`
     is blocked at the callback, not trusted to behave.

  3. Vibe Diff (Day 4): when a finding is CRITICAL, we surface a plain-English
     translation of *why* before a human acts -- see agents/orchestrator.py.

Because MCPTrust audits untrusted code, it is exactly the kind of tool an
attacker would love to subvert. So we hold our own agent to the standard we
measure others against. Dogfooding, again.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

# The only tools the orchestrator is ever allowed to invoke. Note every one is
# read-only by construction -- there is no write/execute/install tool anywhere
# in MCPTrust, so even a fully hijacked orchestrator cannot mutate the host.
ALLOWED_TOOLS = {
    "scan_secrets",
    "scan_injection",
    "scan_dangerous_calls",
    "scan_scope",
    "scan_dependencies",
    "run_full_audit",
}


def _allowed_root() -> Path:
    """Root the auditor is permitted to read under. Defaults to CWD; override
    with MCPTRUST_ALLOWED_ROOT for a tighter sandbox in CI/production."""
    return Path(os.environ.get("MCPTRUST_ALLOWED_ROOT", os.getcwd())).resolve()


def path_within_allowed_root(path: str) -> bool:
    """Reject path traversal / absolute escapes (file-tree allowlist)."""
    try:
        target = Path(path).resolve()
    except (OSError, ValueError):
        return False
    root = _allowed_root()
    return target == root or root in target.parents


def before_tool_guardrail(tool: Any, args: dict, tool_context: Any = None):
    """ADK before_tool_callback.

    Returning a dict short-circuits the tool call with that dict as the result
    (the tool never runs). Returning None lets the call proceed. This is the
    structural half of the Policy Server -- fast, deterministic, no LLM.
    """
    tool_name = getattr(tool, "name", getattr(tool, "__name__", str(tool)))

    # (1) structural gate: only allowlisted read-only tools may run.
    if tool_name not in ALLOWED_TOOLS:
        return {
            "policy_violation": True,
            "reason": f"Tool '{tool_name}' is not on the read-only audit allowlist.",
        }

    # (2) file-tree allowlist / Zero Ambient Authority on the path argument.
    path = (args or {}).get("path")
    if path is not None and not path_within_allowed_root(str(path)):
        return {
            "policy_violation": True,
            "reason": (
                f"Refusing to read '{path}': outside the allowed audit root "
                f"({_allowed_root()}). Blocked by Zero-Ambient-Authority guardrail."
            ),
        }

    return None  # allow the tool to run
