"""Optional ADK runner: invokes the report agent to write an LLM summary.

Isolated in its own module so importing the orchestrator (for its agent
definitions and the deterministic entry point) never drags in the ADK runtime.
This only executes when GOOGLE_API_KEY is set; otherwise the deterministic
summary is used. Kept small on purpose -- the model's only job is prose.
"""

from __future__ import annotations

from ..core.models import TrustReport


def summarize_with_report_agent(path: str, report: TrustReport) -> str:
    """Ask the report agent for a 2-3 sentence plain-English verdict summary.

    Returns "" on any failure so the caller falls back to the deterministic
    summary. The verdict/score are never taken from the model.
    """
    try:
        import asyncio

        from google.adk.runners import InMemoryRunner
        from google.genai import types

        from .orchestrator import _build_agents  # report agent lives in the graph
    except Exception:  # noqa: BLE001
        return ""

    # Build a tiny prompt from the authoritative findings; the model paraphrases.
    findings_brief = "\n".join(
        f"- [{f.severity.label}] {f.title} ({f.location})" for f in report.findings[:12]
    ) or "- (no findings)"
    prompt = (
        f"Target: {report.target}\nVerdict: {report.verdict} (score {report.score}/100)\n"
        f"Findings:\n{findings_brief}\n\n"
        "Write 2-3 sentences a developer can act on. Lead with the verdict and the "
        "single most important reason. Do not soften a BLOCK."
    )

    orchestrator = _build_agents()
    report_agent = orchestrator.sub_agents[-1]

    async def _run() -> str:
        runner = InMemoryRunner(agent=report_agent, app_name="mcptrust")
        session = await runner.session_service.create_session(
            app_name="mcptrust", user_id="cli"
        )
        msg = types.Content(role="user", parts=[types.Part(text=prompt)])
        chunks: list[str] = []
        async for ev in runner.run_async(
            user_id="cli", session_id=session.id, new_message=msg
        ):
            if ev.content and ev.content.parts:
                chunks.extend(p.text for p in ev.content.parts if p.text)
        return "".join(chunks).strip()

    try:
        return asyncio.run(_run())
    except Exception:  # noqa: BLE001
        return ""
