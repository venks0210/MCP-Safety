"""Tools exposed to the ADK specialist agents.

Each function wraps one deterministic analyzer (or the full engine) and returns
plain JSON-serialisable findings. The agents reason about *which* specialist to
consult and how to synthesise the report; the actual detection stays in the
tested, deterministic analyzers. This is the Day 1 factory model: agents route,
deterministic code verifies.

Every tool here is read-only and takes a `path`, so the before_tool_guardrail
in security.py can enforce the file-tree allowlist uniformly.
"""

from __future__ import annotations

from typing import Any

from ..analyzers import (
    DangerousCallAnalyzer,
    DependencyAnalyzer,
    InjectionAnalyzer,
    ScopeAnalyzer,
    SecretScanner,
    run_all,
)
from ..analyzers.base import safe_run
from ..core.ingest import load_target


def _findings_json(analyzer, path: str) -> dict[str, Any]:
    target = load_target(path)  # read-only; never executes the target
    result = safe_run(analyzer, target)
    return {
        "analyzer": result.analyzer,
        "ok": result.ok,
        "error": result.error,
        "findings": [f.to_dict() for f in result.findings],
    }


def scan_secrets(path: str) -> dict:
    """Scan a target MCP server/skill folder for hardcoded credentials."""
    return _findings_json(SecretScanner(), path)


def scan_injection(path: str) -> dict:
    """Scan agent-visible text (tool descriptions, server instructions) for prompt
    injection, hidden Unicode payloads, and homoglyph spoofing."""
    return _findings_json(InjectionAnalyzer(), path)


def scan_dangerous_calls(path: str) -> dict:
    """Scan target code for dangerous execution / exfiltration patterns."""
    return _findings_json(DangerousCallAnalyzer(), path)


def scan_scope(path: str) -> dict:
    """Audit the target manifest for over-broad / least-privilege-violating scopes."""
    return _findings_json(ScopeAnalyzer(), path)


def scan_dependencies(path: str) -> dict:
    """Audit the target's dependencies for typosquats and unpinned versions."""
    return _findings_json(DependencyAnalyzer(), path)


def run_full_audit(path: str) -> dict:
    """Run every analyzer and return a scored trust report for the target."""
    report = run_all(load_target(path))
    return report.to_dict()
