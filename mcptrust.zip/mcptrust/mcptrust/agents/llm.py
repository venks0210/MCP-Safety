"""Model routing + graceful degradation (Day 1 'Intelligent Model Routing').

MCPTrust does the heavy, security-critical work in deterministic Python. The LLM
is used for exactly one thing: writing the human-readable 'Vibe Diff' summary
from findings the analyzers already produced. That is a cheap, low-stakes task,
so we route it to a fast/cheap model -- and if there is no API key at all, we
fall back to the deterministic template summary and the product still works.

No API key is ever read from source. The key comes from the GOOGLE_API_KEY (or
GEMINI_API_KEY) environment variable only -- honouring the competition's
"no keys in code" rule and Day 5's env-var discipline.
"""

from __future__ import annotations

import os

# Cheap model for the summary task (routing: don't pay frontier prices to
# paraphrase a findings list). Overridable via env for flexibility.
SUMMARY_MODEL = os.environ.get("MCPTRUST_SUMMARY_MODEL", "gemini-flash-latest")
ORCHESTRATOR_MODEL = os.environ.get("MCPTRUST_ORCH_MODEL", "gemini-flash-latest")


def has_api_key() -> bool:
    """True if a Gemini/Google API key is present in the environment."""
    return bool(
        os.environ.get("GOOGLE_API_KEY")
        or os.environ.get("GEMINI_API_KEY")
        or os.environ.get("GOOGLE_GENAI_USE_VERTEXAI")
    )
