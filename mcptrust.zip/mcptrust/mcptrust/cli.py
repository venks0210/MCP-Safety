"""MCPTrust command-line interface.

    mcptrust audit <path> [--format terminal|markdown|json] [--use-agents] [--fail-on block|review]

DESIGN: the CLI defaults to the deterministic engine (no key needed). Passing
--use-agents routes through the ADK multi-agent orchestrator, which adds an
LLM-written summary when GOOGLE_API_KEY is set and otherwise degrades gracefully
to the same deterministic result. The exit code is verdict-aware so the CLI can
gate CI (Day 5 Tier-2 pattern): a BLOCK returns non-zero and fails the pipeline.
"""

from __future__ import annotations

import argparse
import json
import sys

from .analyzers import audit_path
from .core.models import TrustReport
from .report import render_markdown, render_plain, render_terminal, summary_text


def _emit(report: TrustReport, fmt: str) -> None:
    if fmt == "json":
        print(json.dumps(report.to_dict(), indent=2, ensure_ascii=False))
    elif fmt == "markdown":
        print(render_markdown(report))
    elif fmt == "plain":
        print(render_plain(report))
    else:
        render_terminal(report)


def _exit_code(report: TrustReport, fail_on: str) -> int:
    order = {"trusted": 0, "review": 1, "block": 2}
    verdict_rank = {"TRUSTED": 0, "REVIEW": 1, "BLOCK": 2}[report.verdict]
    return 1 if verdict_rank >= order.get(fail_on, 2) else 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="mcptrust",
        description="Audit an MCP server or Agent Skill before you install it.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    audit = sub.add_parser("audit", help="Audit a target directory.")
    audit.add_argument("path", help="Path to the MCP server / skill folder to audit.")
    audit.add_argument(
        "--format",
        choices=["terminal", "markdown", "json", "plain"],
        default="terminal",
    )
    audit.add_argument(
        "--use-agents",
        action="store_true",
        help="Route through the ADK multi-agent orchestrator (adds LLM summary if a key is set).",
    )
    audit.add_argument(
        "--fail-on",
        choices=["trusted", "review", "block"],
        default="block",
        help="Exit non-zero if the verdict is at least this severe (for CI gating).",
    )

    args = parser.parse_args(argv)

    if args.command == "audit":
        if args.use_agents:
            # Lazy import so the deterministic CLI never hard-depends on ADK.
            try:
                from .agents.orchestrator import audit_with_agents

                report = audit_with_agents(args.path)
            except Exception as exc:  # noqa: BLE001
                print(f"[agent path unavailable: {exc}; using deterministic engine]", file=sys.stderr)
                report = audit_path(args.path)
        else:
            report = audit_path(args.path)
            report.summary = summary_text(report)

        _emit(report, args.format)
        return _exit_code(report, args.fail_on)

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
