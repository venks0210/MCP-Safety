"""MCPTrust *as* an MCP server.

THE ELEGANT PART: the tool that audits MCP servers is itself an MCP server. A
host agent (Claude Code, Antigravity, Gemini CLI...) can add MCPTrust as a tool
and call `audit_mcp_server` on any candidate *before* installing it -- turning
"install first, hope later" into "audit first, install if clean." This is the
Day 2 consumption pattern used defensively.

Built on the Day 5 reference MCP server (stdio transport, JSON-RPC under the
hood). SECURITY: every tool here is strictly READ-ONLY. MCPTrust reads the
target as text and never executes it (Day 4: Zero Ambient Authority). The
handshake advertises only read-only tools -- there is no tool that can mutate
the filesystem, so a prompt-injected host cannot weaponise MCPTrust itself.

Run:  python -m mcptrust.mcp_server.server
"""

from __future__ import annotations

import asyncio
import json

from ..analyzers import audit_path
from ..report import render_markdown, summary_text

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import TextContent, Tool
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "The 'mcp' package is required to run the MCP server: pip install mcp"
    ) from exc

server = Server("mcptrust")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Advertise MCPTrust's read-only auditing tools to the host agent."""
    return [
        Tool(
            name="audit_mcp_server",
            description=(
                "Security-audit a local MCP server or Agent Skill folder BEFORE "
                "installing it. Returns a trust score (0-100), a verdict "
                "(TRUSTED / REVIEW / BLOCK), and a list of findings covering prompt "
                "injection in tool descriptions, hidden Unicode payloads, hardcoded "
                "secrets, dangerous code, over-scoped permissions, and dependency "
                "typosquats. Read-only: never executes the target."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Filesystem path to the server/skill folder to audit.",
                    },
                    "format": {
                        "type": "string",
                        "enum": ["json", "markdown"],
                        "description": "Output format. Defaults to json.",
                    },
                },
                "required": ["path"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name != "audit_mcp_server":
        return [TextContent(type="text", text=f"Unknown tool: {name}")]

    path = arguments.get("path", "")
    fmt = arguments.get("format", "json")

    # Read-only guard: we only ever *read* the target. There is deliberately no
    # branch here that writes, installs, or executes anything.
    try:
        report = audit_path(path)
        report.summary = summary_text(report)
    except FileNotFoundError:
        return [TextContent(type="text", text=f"Target not found: {path}")]
    except Exception as exc:  # noqa: BLE001
        return [TextContent(type="text", text=f"Audit failed: {exc!r}")]

    if fmt == "markdown":
        return [TextContent(type="text", text=render_markdown(report))]
    return [TextContent(type="text", text=json.dumps(report.to_dict(), indent=2, ensure_ascii=False))]


async def _main() -> None:
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
