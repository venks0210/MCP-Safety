"""MCPTrust deterministic core: models, scoring, and safe ingest."""

from .models import (
    AnalyzerResult,
    Finding,
    Severity,
    TrustReport,
    VERDICT_REVIEW_MIN,
    VERDICT_TRUSTED_MIN,
)
from .ingest import Target, ToolSpec, load_target
from .scoring import build_report, score_findings, verdict_for

__all__ = [
    "AnalyzerResult",
    "Finding",
    "Severity",
    "TrustReport",
    "VERDICT_REVIEW_MIN",
    "VERDICT_TRUSTED_MIN",
    "Target",
    "ToolSpec",
    "load_target",
    "build_report",
    "score_findings",
    "verdict_for",
]
