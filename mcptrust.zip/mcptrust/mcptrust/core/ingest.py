"""Ingest a target MCP server for auditing -- WITHOUT EVER EXECUTING IT.

SECURITY DESIGN DECISION (Day 4, "Zero Ambient Authority" + "we never run the
target"): the single most important property of a supply-chain auditor is that
analysing a malicious package must never run the malicious package. So ingest
does pure, read-only filesystem work: it reads text, it parses manifests, it
extracts the tool descriptions that *would* enter a host agent's context. It
never imports, never `exec`s, never installs dependencies. The target is data,
not code, from MCPTrust's point of view.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# We read source + config text files. We deliberately do NOT read giant binaries
# or lockfiles wholesale; we cap file size so a hostile 2GB file can't OOM us.
TEXT_SUFFIXES = {".py", ".js", ".ts", ".json", ".yaml", ".yml", ".toml", ".md", ".txt", ".cfg"}
MAX_FILE_BYTES = 512 * 1024  # 512 KB per file is plenty for MCP servers


@dataclass
class ToolSpec:
    """A single tool as advertised by the server's manifest/code.

    The `description` field is the crown jewel from a security standpoint: MCP
    tool descriptions are injected verbatim into the *consuming* agent's context
    (Day 2). That makes them the primary prompt-injection surface (Day 4). We
    surface them as first-class objects so the injection analyzer can target
    exactly the text that reaches the model.
    """

    name: str
    description: str = ""
    schema: dict[str, Any] = field(default_factory=dict)
    source: str = ""  # where we found it (manifest path or "code")


@dataclass
class Target:
    """A loaded-but-not-executed MCP server."""

    root: Path
    files: dict[str, str] = field(default_factory=dict)   # rel path -> text
    manifest: dict[str, Any] = field(default_factory=dict)
    tools: list[ToolSpec] = field(default_factory=list)
    manifest_path: str = ""

    @property
    def name(self) -> str:
        return self.manifest.get("name") or self.root.name

    def iter_text(self):
        """Yield (relpath, text) for every readable text file."""
        yield from self.files.items()

    def context_surface(self) -> list[tuple[str, str]]:
        """All text that would enter a host agent's context if this server were
        loaded: server name/instructions + every tool name/description + schema
        field descriptions. This is exactly the injection attack surface."""
        surface: list[tuple[str, str]] = []
        if self.manifest.get("instructions"):
            surface.append(("manifest:instructions", str(self.manifest["instructions"])))
        for i, t in enumerate(self.tools):
            if t.description:
                surface.append((f"tool[{i}]:{t.name}.description", t.description))
            for prop, spec in (t.schema.get("properties") or {}).items():
                desc = spec.get("description") if isinstance(spec, dict) else None
                if desc:
                    surface.append((f"tool[{i}]:{t.name}.{prop}.description", str(desc)))
        return surface


def _load_manifest(root: Path) -> tuple[dict[str, Any], str]:
    """Look for a machine-readable manifest describing the server + its tools.

    We accept a few common conventions. A real MCP server advertises tools at
    runtime via the protocol handshake; for static auditing we rely on a
    committed manifest (mcp.json / server.json) OR fall back to parsing tool
    declarations out of the code. A committed manifest is the safest source
    because reading it never runs anything.
    """
    for candidate in ("mcp.json", "server.json", "mcptrust.manifest.json"):
        p = root / candidate
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8", errors="replace")), candidate
            except json.JSONDecodeError:
                return {}, candidate
    return {}, ""


def _tools_from_manifest(manifest: dict[str, Any], source: str) -> list[ToolSpec]:
    tools: list[ToolSpec] = []
    for t in manifest.get("tools", []) or []:
        if not isinstance(t, dict):
            continue
        tools.append(
            ToolSpec(
                name=str(t.get("name", "?")),
                description=str(t.get("description", "")),
                schema=t.get("inputSchema") or t.get("schema") or {},
                source=source,
            )
        )
    return tools


def load_target(path: str | Path) -> Target:
    """Read a target MCP server from disk. Read-only. Never executes anything."""
    root = Path(path).resolve()
    if not root.exists():
        raise FileNotFoundError(f"target not found: {root}")
    if root.is_file():
        root = root.parent

    files: dict[str, str] = {}
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES:
            continue
        try:
            if p.stat().st_size > MAX_FILE_BYTES:
                continue
            files[str(p.relative_to(root))] = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

    manifest, manifest_path = _load_manifest(root)
    tools = _tools_from_manifest(manifest, manifest_path or "manifest")

    return Target(
        root=root,
        files=files,
        manifest=manifest,
        tools=tools,
        manifest_path=manifest_path,
    )
