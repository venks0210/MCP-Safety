"""Deterministic trust scoring.

DESIGN DECISION: scoring is a pure function of the findings list. No model call,
no randomness, no hidden state. Given the same findings you always get the same
score and verdict -- which is exactly what a security gate needs (Day 4: trust
is "continuously earned and verified", but the *measurement* must be reproducible
for audit). An LLM writes the prose summary; it never touches the number.

The scoring model is intentionally simple and explainable:

    score = 100 - sum(penalty(finding))     (clamped to 0..100)

with a diminishing-returns cap per threat class so that, say, fifty LOW findings
can't nuke a server that has one genuine issue and a lot of lint noise. The cap
also stops a noisy analyzer from dominating the verdict.
"""

from __future__ import annotations

from collections import defaultdict

from .models import (
    Finding,
    Severity,
    TrustReport,
    VERDICT_REVIEW_MIN,
    VERDICT_TRUSTED_MIN,
)

# Max total penalty any single threat_class may contribute. Prevents one chatty
# category from swamping the score; a server with 40 unpinned deps is a MEDIUM
# concern, not 40 x MEDIUM.
PER_CLASS_CAP = 45


def verdict_for(score: int) -> str:
    """Pure score -> band mapping (no knowledge of individual findings)."""
    if score >= VERDICT_TRUSTED_MIN:
        return "TRUSTED"
    if score >= VERDICT_REVIEW_MIN:
        return "REVIEW"
    return "BLOCK"


def final_verdict(score: int, findings: list[Finding]) -> str:
    """Verdict WITH the critical-override safety rule.

    SECURITY DESIGN DECISION: a single CRITICAL finding (a hardcoded key, a
    prompt-injection payload in a tool description, a wildcard scope) forces a
    BLOCK verdict even if the numeric score would otherwise land in REVIEW.
    Rationale: the cost of installing one genuinely malicious server dwarfs the
    cost of a human double-check, so we refuse to average a critical away behind
    a pile of otherwise-clean signal. This is the gate behaving conservatively
    on purpose (Day 4).
    """
    if any(f.severity is Severity.CRITICAL for f in findings):
        return "BLOCK"
    return verdict_for(score)


def score_findings(findings: list[Finding]) -> int:
    """Return an integer trust score in [0, 100] from a list of findings."""
    per_class: dict[str, int] = defaultdict(int)
    for f in findings:
        per_class[f.threat_class] += int(f.severity)

    total_penalty = 0
    for _threat_class, raw in per_class.items():
        total_penalty += min(raw, PER_CLASS_CAP)

    return max(0, min(100, 100 - total_penalty))


def build_report(
    target: str,
    findings: list[Finding],
    analyzers_run: list[str],
    summary: str = "",
) -> TrustReport:
    """Assemble the final TrustReport, sorting findings worst-first."""
    ordered = sorted(findings, key=lambda f: int(f.severity), reverse=True)
    score = score_findings(ordered)
    verdict = final_verdict(score, ordered)

    stats: dict[str, int] = {s.label: 0 for s in Severity if s is not Severity.INFO}
    for f in ordered:
        if f.severity is not Severity.INFO:
            stats[f.severity.label] += 1

    return TrustReport(
        target=target,
        score=score,
        verdict=verdict,
        findings=ordered,
        summary=summary,
        analyzers_run=analyzers_run,
        stats=stats,
    )
