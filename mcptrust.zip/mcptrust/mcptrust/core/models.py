"""Core data models shared across every analyzer and agent in MCPTrust.

DESIGN DECISION (Day 3 "shift intelligence left"): the entire finding/scoring
vocabulary is expressed as plain, deterministic dataclasses -- not LLM output.
Every analyzer, the scorer, the report renderers, the MCP server, and the ADK
agents all speak this one schema. That means the deterministic core is fully
testable and runs with ZERO API keys, and the LLM layer only ever *decorates*
these structures with prose. It never invents severities or scores.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field, asdict
from typing import Any


class Severity(enum.IntEnum):
    """Ordered severities. IntEnum so we can sort/compare and map to a penalty.

    The numeric value is deliberately the scoring penalty (points subtracted
    from a 100-point trust score per occurrence, before capping). Keeping the
    penalty *in* the enum keeps scoring auditable: there is exactly one place a
    severity is defined and exactly one place it maps to a number.
    """

    INFO = 0        # informational only, no penalty
    LOW = 5         # style / hygiene
    MEDIUM = 12     # should be reviewed before trusting
    HIGH = 25       # likely dangerous
    CRITICAL = 45   # do-not-install class finding

    @property
    def label(self) -> str:
        return self.name


# Verdict thresholds. A server is only "TRUSTED" if it clears a high bar,
# because the cost of a false-negative (installing malware) is far higher than
# a false-positive (asking a human to look). This asymmetry is the whole point
# of a supply-chain gate (Day 4, Pillar 4 & 7).
VERDICT_TRUSTED_MIN = 80
VERDICT_REVIEW_MIN = 50


@dataclass
class Finding:
    """A single issue discovered in a target MCP server.

    `evidence` is a short, human-readable snippet (already truncated + made safe
    for display -- we never echo full secrets). `location` points at where it
    was found so a human reviewer can jump straight to it.
    """

    analyzer: str                 # which analyzer produced this (e.g. "secrets")
    threat_class: str             # short machine tag, e.g. "hardcoded_secret"
    severity: Severity
    title: str                    # one-line summary
    detail: str                   # why this matters, in plain English
    location: str = ""            # "file.py:42" or "manifest:tools[0].description"
    evidence: str = ""            # short, redacted snippet
    remediation: str = ""         # what the author should do about it

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["severity"] = self.severity.label
        d["penalty"] = int(self.severity)
        return d


@dataclass
class AnalyzerResult:
    """Everything one analyzer found, plus whether it ran cleanly."""

    analyzer: str
    findings: list[Finding] = field(default_factory=list)
    ok: bool = True               # False if the analyzer itself errored
    error: str = ""

    def add(self, finding: Finding) -> None:
        self.findings.append(finding)


@dataclass
class TrustReport:
    """The final artifact a user (or a host agent) receives before installing."""

    target: str
    score: int
    verdict: str                  # TRUSTED | REVIEW | BLOCK
    findings: list[Finding] = field(default_factory=list)
    summary: str = ""             # plain-English "Vibe Diff"-style explanation
    analyzers_run: list[str] = field(default_factory=list)
    stats: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "score": self.score,
            "verdict": self.verdict,
            "summary": self.summary,
            "analyzers_run": self.analyzers_run,
            "stats": self.stats,
            "findings": [f.to_dict() for f in self.findings],
        }

    @property
    def is_blocked(self) -> bool:
        return self.verdict == "BLOCK"
