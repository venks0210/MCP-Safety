"""Scoring is a pure function -> easy, fast, deterministic unit tests."""

from mcptrust.core.models import Finding, Severity
from mcptrust.core.scoring import PER_CLASS_CAP, final_verdict, score_findings, verdict_for


def _f(threat_class: str, severity: Severity) -> Finding:
    return Finding(
        analyzer="t",
        threat_class=threat_class,
        severity=severity,
        title="t",
        detail="t",
    )


def test_empty_is_perfect():
    assert score_findings([]) == 100
    assert verdict_for(100) == "TRUSTED"


def test_single_critical_blocks():
    findings = [_f("hardcoded_secret", Severity.CRITICAL)]
    assert score_findings(findings) == 100 - int(Severity.CRITICAL)
    # A lone CRITICAL scores 55 (a REVIEW band) but the critical-override forces BLOCK.
    assert final_verdict(score_findings(findings), findings) == "BLOCK"


def test_verdict_bands():
    assert verdict_for(80) == "TRUSTED"
    assert verdict_for(79) == "REVIEW"
    assert verdict_for(50) == "REVIEW"
    assert verdict_for(49) == "BLOCK"


def test_per_class_cap_prevents_pile_on():
    # 20 LOW findings of the SAME class must not exceed the per-class cap.
    findings = [_f("unpinned_dependency", Severity.LOW) for _ in range(20)]
    score = score_findings(findings)
    assert score == 100 - PER_CLASS_CAP


def test_distinct_classes_accumulate():
    findings = [
        _f("hardcoded_secret", Severity.CRITICAL),
        _f("prompt_injection", Severity.CRITICAL),
    ]
    # Two distinct classes each cap-limited but well under cap individually.
    assert score_findings(findings) == 100 - 2 * int(Severity.CRITICAL)
