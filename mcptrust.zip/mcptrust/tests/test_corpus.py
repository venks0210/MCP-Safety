"""The eval gate (Day 1 + Day 3).

This is the difference between 'a demo that worked once' and 'a capability':
the full auditor is run over the labelled corpus and every sample must land on
its expected verdict AND surface its expected threat class. If a code change
regresses detection, this test goes red and blocks the merge -- eval coverage,
not vibes.
"""

import json
from pathlib import Path

import pytest

from mcptrust.analyzers import audit_path

CORPUS = Path(__file__).resolve().parent.parent / "corpus"
LABELS = json.loads((CORPUS / "labels.json").read_text())["samples"]


@pytest.mark.parametrize("sample", LABELS, ids=[s["path"] for s in LABELS])
def test_corpus_sample(sample):
    report = audit_path(str(CORPUS / sample["path"]))

    # 1. Verdict must match ground truth.
    assert report.verdict == sample["expected_verdict"], (
        f"{sample['path']}: expected {sample['expected_verdict']}, "
        f"got {report.verdict} (score={report.score})"
    )

    # 2. Score floor for clean samples.
    if "min_score" in sample:
        assert report.score >= sample["min_score"]

    # 3. Clean samples must have no HIGH/CRITICAL findings.
    if sample.get("must_be_clean"):
        bad = [f for f in report.findings if int(f.severity) >= 25]
        assert not bad, f"clean sample flagged: {[f.title for f in bad]}"

    # 4. Poisoned samples must surface the expected threat class.
    if "must_contain_threat" in sample:
        threats = {f.threat_class for f in report.findings}
        assert sample["must_contain_threat"] in threats, (
            f"{sample['path']}: expected threat "
            f"{sample['must_contain_threat']}, got {sorted(threats)}"
        )


def test_corpus_pass_at_k_style_stability():
    """pass^k-style check (Day 3): the deterministic engine must give the SAME
    verdict on repeated runs. A supply-chain gate that flickers is useless."""
    sample = LABELS[0]
    verdicts = {audit_path(str(CORPUS / sample["path"])).verdict for _ in range(5)}
    assert len(verdicts) == 1
