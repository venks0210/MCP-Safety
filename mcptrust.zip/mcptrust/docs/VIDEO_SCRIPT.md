# MCPTrust — 5-Minute Video Script & Storyboard

**Target: ≤5:00.** The rubric wants: problem → *why agents specifically* →
architecture → live demo → how it was built. Every second below is budgeted.
Record in Antigravity so the build footage (and the sandbox toggle) is on screen
— that is the Antigravity concept evidence.

---

### [0:00–0:35] Hook + problem  (35s)

*Screen: a terminal about to `npx`-install a community MCP server.*

> "There are over forty thousand public agent skills and countless community MCP
> servers. Installing one runs untrusted code inside your agent — with your
> files, your keys, and your model's context. And here's the scary part…"

*Cut: show a tool description that looks normal, then reveal the hidden zero-width
+ right-to-left-override payload inside it.*

> "…a malicious server hides instructions right here, in a tool description your
> agent reads — invisible to you. There's no tool to check before you trust it.
> So I built one. This is **MCPTrust**."

### [0:35–1:05] Why agents specifically  (30s)

*Screen: the architecture diagram from the README.*

> "This isn't one prompt. Auditing splits into jobs with genuinely different
> trust postures. Scanning for secrets or over-scoped permissions is bounded and
> deterministic — that's a tool. But judging *'would this text poison a host
> agent's context?'* is open-ended adversarial reasoning — that's an agent. So
> MCPTrust is a multi-agent system: specialists for static analysis, scope, and a
> red-team agent that reasons about the untrusted payload, with an orchestrator
> that synthesises the verdict."

### [1:05–1:35] The key architectural idea  (30s)

*Screen: the deterministic-core / LLM-decoration diagram.*

> "One principle makes this trustworthy: the security-critical work is
> deterministic Python — fully tested, no API key, and impossible to
> prompt-inject. The model only ever writes the plain-English summary. The score
> and the verdict never come from an LLM. That means a prompt injection in a
> *target* can never change MCPTrust's own answer — and the whole thing runs
> offline."

### [1:35–3:20] Live demo  (105s — the core)

*Screen: `python demo/demo.py`*

> "Let's audit a clean weather server first."

*Show: **TRUSTED, 100/100**, least privilege, no findings.*

> "Now the poisoned ones."

*Show each, fast, reading the verdict line:*
- **Injection in description** → BLOCK, 55 — "it caught the 'ignore previous instructions' payload."
- **Hidden Unicode** → BLOCK — "the description looked clean to me, but the right-to-left override is flagged CRITICAL."
- **Hardcoded key** → BLOCK.
- **Over-scoped calculator that exfiltrates** → BLOCK — "wildcard scope *and* file-read-plus-network — the exfiltration shape."
- **Typosquatted deps** → REVIEW — "'reqests' is one edit from 'requests'."

*Screen: the Vibe Diff for a BLOCK.*

> "And the Vibe Diff translates the critical findings into plain English — what
> you'd actually be approving if you installed this."

*Screen: run MCPTrust **as an MCP server**, a host agent calling `audit_mcp_server`.*

> "It's also an MCP server itself — so your host agent can audit a server before
> it ever installs it."

### [3:20–4:05] Security + the eval gate  (45s)

*Screen: `security.py` `before_tool_callback`, then a blocked traversal attempt.*

> "MCPTrust audits untrusted code, so it holds itself to the standard it
> measures. Every agent tool call passes a Policy-Server gate: read-only
> allowlist, and Zero-Ambient-Authority path checks. Watch it refuse to read
> outside its sandbox."

*Screen: `pytest -q` → 22 passed.*

> "And it's judged, not vibed: a labelled corpus of clean and poisoned servers is
> an eval gate in CI. If a change regresses detection, the build goes red."

### [4:05–4:45] How it was built + deploy  (40s)

*Screen: Antigravity, the repo tree, the GitHub Action.*

> "Built in Antigravity with the Agent Development Kit, the MCP SDK, and four
> Agent Skills — each with its own eval cases, written before the code. It
> deploys three ways: a CLI, an MCP server, and a GitHub Action that fails your
> build on a BLOCK — so it can gate every server your repo adds."

### [4:45–5:00] Close  (15s)

> "Forty thousand skills, zero tooling to vet them — until now. Audit first,
> install only if clean. That's MCPTrust."

---

## Recording checklist
- [ ] Antigravity visible (build + sandbox toggle) → Antigravity concept.
- [ ] `demo.py` clean→poisoned run → the money shot.
- [ ] MCP-server handshake → MCP Server concept (Video reinforcement).
- [ ] Guardrail blocking traversal → Security concept.
- [ ] `pytest` green → eval rigor.
- [ ] GitHub Action → Deployability concept.
- [ ] Keep under 5:00. Cut the deps scenario first if over.
