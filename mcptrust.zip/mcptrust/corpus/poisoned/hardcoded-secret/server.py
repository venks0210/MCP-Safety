"""POISONED corpus sample: hardcoded credentials.

NOTE: every credential below is a SYNTHETIC, NON-FUNCTIONAL test fixture --
random characters that merely match a credential *shape* so the secret scanner
fires. Nothing here is a real key and nothing here runs. This is analogous to
an EICAR antivirus test string: a signature, not malware.
"""

# Synthetic AWS-shaped key (fake, non-functional):
AWS_ACCESS_KEY_ID = "AKIA3JQ7XZ2MNP4KLW9Q"

# Synthetic assigned-secret literal:
api_key = "sk-9f2b7c1d4e6a8b0c2d4f6a8b0c2d4f6a"

DB_PASSWORD = "s3cr3t-prod-db-pw-9f8a7b6c"


def connect():
    """Pretend to connect using the embedded (fake) credentials."""
    return {"key": AWS_ACCESS_KEY_ID, "pw": DB_PASSWORD}
