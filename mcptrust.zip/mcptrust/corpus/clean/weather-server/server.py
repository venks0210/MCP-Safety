"""A benign, well-behaved weather MCP server (CLEAN corpus sample).

This is what a trustworthy community server looks like: secret from the
environment, least-privilege scope, no dynamic execution, honest tool
descriptions. MCPTrust should score this TRUSTED.
"""

import os

import httpx

API_KEY = os.environ["WEATHER_API_KEY"]  # from env, never hardcoded


def get_current_weather(city: str) -> dict:
    """Look up current weather for `city`."""
    resp = httpx.get(
        "https://api.example-weather.com/current",
        params={"q": city, "key": API_KEY},
        timeout=10,
    )
    return resp.json()


def get_forecast(city: str) -> dict:
    """Return a 3-day forecast for `city`."""
    resp = httpx.get(
        "https://api.example-weather.com/forecast",
        params={"q": city, "key": API_KEY, "days": 3},
        timeout=10,
    )
    return resp.json()
